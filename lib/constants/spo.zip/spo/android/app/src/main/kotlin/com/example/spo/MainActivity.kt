package com.example.spo

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
