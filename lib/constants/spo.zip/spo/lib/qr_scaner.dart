import 'dart:developer';
import 'dart:io';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:qr_code_scanner/qr_code_scanner.dart';

import 'phone_auth.dart';
import 'presentation/home/home.dart';

class QRViewEx extends StatefulWidget {
  const QRViewEx({Key? key}) : super(key: key);

  @override
  State<QRViewEx> createState() => _QRViewExState();
}

class _QRViewExState extends State<QRViewEx> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  Barcode? result;
  QRViewController? controller;



  // In order to get hot reload to work we need to pause the camera if the platform
  // is android, or resume the camera if the platform is iOS.
  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller!.pauseCamera();
    } else if (Platform.isIOS) {
      controller!.resumeCamera();
    }
  }
  @override
  Widget build(BuildContext context) {
  double  h=MediaQuery.of(context).size.height;
  double  w=MediaQuery.of(context).size.width;
    var scanArea = (MediaQuery.of(context).size.width < 600 ||
        MediaQuery.of(context).size.height < 600)
        ? 250.0
        : 300.0;
    return Scaffold(
      body: Stack(
        children: [

          Column(
            children: <Widget>[
              Expanded(
                flex: 5,
                child: QRView(
                  key: qrKey,
                  onQRViewCreated: _onQRViewCreated,
                  overlay: QrScannerOverlayShape(
                      borderColor: Colors.tealAccent,
                      borderRadius: 10,
                      borderLength: 30,
                      borderWidth: 10,
                      cutOutSize: scanArea),
                  onPermissionSet: (ctrl, p) => _onPermissionSet(context, ctrl, p),
                ),
              ),
              Expanded(
                flex:0,
                child:(result !=  null
                    ? Text(  'أقراء الباركود : ${describeEnum(result!.format)}   Data: ${result!.code}')
                    : const Text('Scan a code')

                ),
              )
            ],
          ),

          Align(
              alignment: Alignment.bottomCenter,
              child: SizedBox(
                height: 250,
                child: ClipPath(
                  clipper: BottomWaveShape(),
                  child: Container(
                    color: const Color(0xff3ca0b5),
                  ),
                ),
              )),
          Container(
              padding: EdgeInsets.only(top: h*0.3),
              margin: EdgeInsets.only(top:h*0.5,left:w*0.1 ),
              alignment: Alignment.centerLeft,
              height: h* 200,
              width: w* 200,

              child: Text
                ('QR وجه الكامرة نحو رمز ',
                style: TextStyle(color: Colors.white,fontSize: 14,fontWeight: FontWeight.bold),)
          ),
        ],
      )
    );
  }
  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      setState(() {
        result = scanData;

      });
    });
  }
  void _onPermissionSet(BuildContext context, QRViewController ctrl, bool p) {
    log('${DateTime.now().toIso8601String()}_onPermissionSet $p');
    if (!p) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('no Permission')),

      );
    }
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }
}
gotohome(){
  PinCodeVerificationScreen();
}

/*

class QRViewEx extends State<StatefulWidget> {
  final GlobalKey qrKey = GlobalKey(debugLabel: 'QR');
  Barcode? result;
  QRViewController? controller;

  // In order to get hot reload to work we need to pause the camera if the platform
  // is android, or resume the camera if the platform is iOS.
  @override
  void reassemble() {
    super.reassemble();
    if (Platform.isAndroid) {
      controller!.pauseCamera();
    } else if (Platform.isIOS) {
      controller!.resumeCamera();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Column(
        children: <Widget>[
          Expanded(
            flex: 5,
            child: QRView(
              key: qrKey,
              onQRViewCreated: _onQRViewCreated,
            ),
          ),
          Expanded(
            flex: 1,
            child: Center(
              child: (result != null)
                  ? Text(
                  'Barcode Type: ${describeEnum(result!.format)}   Data: ${result!.code}')
                  : Text('Scan a code'),
            ),
          )
        ],
      ),
    );
  }

  void _onQRViewCreated(QRViewController controller) {
    this.controller = controller;
    controller.scannedDataStream.listen((scanData) {
      setState(() {
        result = scanData;
      });
    });
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }
}*/
class BottomWaveShape extends CustomClipper<Path> {
  @override
  getClip(Size size) {
    double h = size.height;
    double w = size.width;

    var p = Path();
    p.lineTo(0, 0);
    p.cubicTo(10 * 2 / 10, 150, 2 * 50 * 5 / 2, 20, w - 10, h - 10);
    p.lineTo(w, h);
    p.lineTo(0, h);
    p.lineTo(0, 0);
    p.close();

    return p;
  }

  @override
  bool shouldReclip(CustomClipper oldClipper) => true;
}