import 'package:fl_country_code_picker/fl_country_code_picker.dart';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class Login extends StatefulWidget {
  const Login({Key? key}) : super(key: key);

  @override
  State<Login> createState() => _LoginState();
}

class _LoginState extends State<Login> {
  final _formKey = GlobalKey<FormState>();
  final countryPicker = const FlCountryCodePicker();
  CountryCode countryCode = const CountryCode(name: 'Iraq', code: 'IQ', dialCode: '+964');
  TextEditingController txtPhone = TextEditingController();
  final FocusNode fcsPhone = FocusNode();
  @override
  Widget build(BuildContext context) {
    return   Scaffold(
      body:   Container(
        child:  Column(
          children: [
            Image(

              image:    AssetImage("asset/images/logo -2.png"),width:MediaQuery.of(context).size.width*0.998,height:MediaQuery.of(context).size.height  ,
              fit: BoxFit.cover,

            ),
             Container(

                child: Stack(
                    alignment: AlignmentDirectional.bottomCenter,
                    fit: StackFit.expand,
                    children: <Widget>[

                      SingleChildScrollView(
                        child:
                        Column(
                          children: [
                            Positioned(
                                top: 50,
                                child: InkWell(
                                  borderRadius: BorderRadius.circular(900),
                                  autofocus: true,
                                  child: Lottie.asset('asset/images/qr-scanning.json'),
                                  onTap: () {},
                                )),
                            Container(
                              margin: const EdgeInsets.only(top: 4,),
                              height: 200,
                              width: 200,
                              color: Colors.transparent,
                              child: Column(
                                children: [
                                  const SizedBox(
                                    height: 10,
                                  ),
                                  //,text input  pone number
                                  Container(
                                    margin: const EdgeInsets.all(2),
                                    child:   TextFormField(
                                      // onFieldSubmitted: (term) {
                                      //   FocusScope.of(context).requestFocus(fcsPhone2);
                                      // },
                                      maxLines: null,
                                      minLines: 1,
                                      maxLength: 10,
                                      textAlign: TextAlign.center,
                                      textInputAction: TextInputAction.done,
                                      controller: txtPhone,
                                      keyboardType: TextInputType.number,
                                      focusNode: fcsPhone,
                                      cursorColor: Colors.black,
                                      style: const TextStyle(color: Colors.black,
                                          fontWeight: FontWeight.bold),
                                      decoration: InputDecoration(
                                        border: OutlineInputBorder(
                                            borderRadius: BorderRadius.circular(10)
                                        ),
                                        prefix: GestureDetector(
                                          onTap: () async{
                                            final code = await countryPicker.showPicker(
                                              context: context,
                                              scrollToDeviceLocale: true,
                                            );
                                            if (code != null) {
                                              countryCode = code;
                                              setState(() {});
                                            }
                                          },
                                          child: Container(
                                            padding: const EdgeInsets.symmetric(horizontal: 8.0, vertical: 4.0),
                                            margin: const EdgeInsets.symmetric(horizontal: 8.0),
                                            decoration: BoxDecoration(
                                                border: Border.all(color: Colors.teal),
                                                color: Colors.teal,
                                                borderRadius: const BorderRadius.all(Radius.circular(5.0))),
                                            child: Text(countryCode == null ? '+964' : countryCode.dialCode,

                                                style: const TextStyle(color: Colors.black)),
                                          ),
                                        ),
                                        fillColor: Colors.black,
                                        // filled: true,
                                        counterText: "",
                                        labelText: 'رقم الهاتف',
                                        labelStyle: const TextStyle(color: Colors.black),
                                        // border: fieldBorder,
                                      ),
                                      validator: (String? value) {
                                        if (value!.trim().isEmpty) {
                                          return 'ادخل رقم الهاتف';
                                        } else if(value.trim().length > 10){
                                          return 'لقد تجاوزت 10 مراتب';
                                        } else {
                                          return null;
                                        }
                                      },
                                    ),
                                  ),
                                  SizedBox(
                                    height: 20,
                                  ),

                                  ElevatedButton(
                                      style: ButtonStyle(
                                        backgroundColor: MaterialStatePropertyAll<Color>(Colors.teal),
                                      ),
                                      onPressed: () {}, child: const Text('دخول',style: TextStyle(color: Colors.black,fontWeight: FontWeight.bold),))
                                ],
                              ),
                            ),



                          ],

                        ),



                      ),
                    ]
                )
            ),
          ],
        )


      ),
    );
  }
}
