import 'dart:ui';

import 'package:flutter/material.dart';
import 'package:spo/widgets/gradient_ball.dart';
import 'package:spo/widgets/my_button.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: SafeArea(
            child: Stack(children: [
      Stack(children: [
        BackdropFilter(
            filter: ImageFilter.blur(
          sigmaX: 10.0,
          sigmaY: 10.0,
        )),
        Container(
          padding: const EdgeInsets.only(
            top: 20,
            left: 300,
          ),
          child: GradientBall(
            colors: [
              Colors.purple.withOpacity(.2),
              Colors.purple.withOpacity(.8),
            ],
            size: const Size(100, 100),
          ),
        ),
        Container(
          padding: const EdgeInsets.only(
            top: 40,
          ),
          child: GradientBall(
            colors: [
              Colors.purple,
              Colors.purple.withOpacity(.8),
            ],
            size: const Size(150, 150),
          ),
        ),
        Container(
          padding: const EdgeInsets.only(
            top: 300,
            left: 250,
          ),
          child: GradientBall(
            colors: [
              Colors.purple.withOpacity(.2),
              Colors.purple.withOpacity(.8),
            ],
            size: const Size(150, 150),
          ),
        ),
      ]),
      Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
        const SizedBox(
          height: 40,
        ),
        const Image(image: AssetImage('asset/images/logo.png'), height: 200),
        const SizedBox(
          height: 20,
        ),
        Container(
            margin: const EdgeInsets.only(left: 40),
            child: Column(
              children: [
                const Text(
                  'كيفية تسجيل الدخول ؟',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                    fontWeight: FontWeight.bold,
                    fontSize: 20,
                  ),
                ),
                const Text(
                  'اضغط على زر التسجيل ادناهووجه الكامرة الى'
                  "\n"
                  'QR المطبوع في بطاقة الهوية !',
                  textDirection: TextDirection.rtl,
                  textAlign: TextAlign.right,
                  style: TextStyle(
                      fontWeight: FontWeight.normal,
                      fontSize: 15,
                      color: Colors.black),
                ),
              ],
            )),
        const SizedBox(
          height: 20,
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          child: MyButton(
            text: const Text(
              'نسجيل الدخول باستخدام qr',
              style: TextStyle(color: Colors.white, fontSize: 18),
            ),
            color: const Color(0xff3ca0b5),
            icon: Icons.qr_code,
            iconColor: Colors.white,
            onPressed: () {},
          ),
        )
      ]),
      Align(
          alignment: Alignment.bottomCenter,
          child: SizedBox(
            height: 250,
            child: ClipPath(
              clipper: BottomWaveShape(),
              child: Container(
                color: const Color(0xff3ca0b5),
              ),
            ),
          )),
    ])));
  }
}

class BottomWaveShape extends CustomClipper<Path> {
  @override
  getClip(Size size) {
    double h = size.height;
    double w = size.width;

    var p = Path();
    p.lineTo(0, 0);
    p.cubicTo(11 * 2 / 4, 220, 3 * 80 * 1 / 1, 25, w - 10, h - 10);
    p.lineTo(w, h);
    p.lineTo(0, h);
    p.lineTo(0, 0);
    p.close();

    return p;
  }

  @override
  bool shouldReclip(CustomClipper oldClipper) => true;
}
