

import 'package:flutter/material.dart';

import 'package:sponsor/notification.dart';
import 'package:sponsor/presentation/home/home.dart';

 import '../presentation/login/login.dart';

class Routes{
  static const String splashRoute='/';
      static const String loginRoute="/login";
      static const String homepageRoute="/HomePage";
      static const String PinCodeVerificationScreen="/PinCodeVerificationScreen";

}
class RouteGenerator{
  static Route<dynamic> getRoute(RouteSettings settings){
    switch(settings.name){
     // case Routes.splashRoute :
        //return MaterialPageRoute(builder: (context) => const Splash());
      case Routes.loginRoute :
        return MaterialPageRoute(builder: (context) =>Login()

            )
        );
      case Routes.homeRoute :
        return MaterialPageRoute(builder: (context) => const Home();




                default:
        return unDefinedRoute();
    }
  }

  static Route<dynamic> unDefinedRoute() {
    return MaterialPageRoute(
        builder: (_) => Scaffold(
          appBar: AppBar(
            title: const Text('no Route Found'),
          ),
          body: const Center(child: Text('no Route Found')),
        ));
  }
}